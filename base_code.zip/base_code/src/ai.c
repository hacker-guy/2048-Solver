#include <time.h>
#include <stdlib.h>
#include <inttypes.h>
#include "ai.h"
#include "utils.h"
#include "priority_queue.h"

struct heap h;

int arrsize = 100000;

void initialize_ai(){
	heap_init(&h);
}

/**
 * Find best action by building all possible paths up to depth max_depth
 * and back propagate using either max or avg
 */
move_t get_next_move( uint8_t board[SIZE][SIZE], int max_depth, 
	propagation_t propagation ){

	node_t **explored = malloc(sizeof(node_t*)*arrsize);
	if (explored == NULL) { 
		perror("malloc Node"); 
		exit (EXIT_FAILURE); 
	}
	nodeScore_t *scoreArr = malloc(4*sizeof(nodeScore_t));
	if (scoreArr == NULL) { 
		perror("malloc Node"); 
		exit (EXIT_FAILURE); 
	}
	scoreArr[left].score = 0;
	scoreArr[right].score = 0;
	scoreArr[up].score = 0;
	scoreArr[down].score = 0;
	
	node_t *start = initializePointer();
	assign_board(start->board, board);

	heap_push(&h, start);
	
	int countExpl = 0;
	while (h.count > 0) {
		node_t* pointer = heap_delete(&h);
		add_explored(pointer, explored, countExpl++);
		if (pointer->depth < max_depth) {
			move_t i;
			for (i = left; i<=down; i++) {
				node_t *pointerNew = applyAction(pointer, i);
				if  (pointerNew != NULL &&
					!equalsBoard(pointerNew->board, pointer->board)) {
					heap_push(&h, pointerNew);
					propagateBack(pointerNew, scoreArr, propagation); 
				} else {
					free(pointerNew);
				}
			}
		}
	}
	
//	free_memory(explored, countExpl);
	
	move_t best_action = select_bestAction(scoreArr); //SELECT BEST ACTION
	
	return best_action;
}


node_t* initializePointer() {
	
	node_t* pointer = malloc(sizeof(node_t));
	if (pointer == NULL) { 
		perror("malloc Node"); 
		exit (EXIT_FAILURE); 
	}
	pointer->priority = (uint32_t)0;
	pointer->depth = 0;
	pointer->num_childs = 0;
	pointer->parent = NULL;
	
	return pointer;
}

void assign_board(uint8_t to[SIZE][SIZE], uint8_t from[SIZE][SIZE]) {
	int i, j;
	for (i = 0; i<SIZE; i++) {
		for (j=0; j<SIZE; j++) {
			to[i][j] = from[i][j];
		}
	}
}

void updateVariables(node_t* pointer, node_t* parent, move_t move, 
	int doubles) {
	pointer->parent = parent;
//	parent->num_childs++;
	pointer->depth = parent->depth + 1;
	pointer->move = move;
}

int equalsBoard(uint8_t board1[SIZE][SIZE], uint8_t board2[SIZE][SIZE]) {
	int i, j;
	for (i = 0; i < SIZE; i++) {
        for (j = 0; j < SIZE; j++) {
            if (board1[i][j] != board2[i][j]) {
            	return 0;
            }
        }
    }
    return 1;
}

void printBoard(uint8_t board[SIZE][SIZE]) {
	int i,j;
    for (i = 0; i < SIZE; i++) {
        for (j = 0; j < SIZE; j++) {
            printf("%" PRIu8 " ", board[j][i]);
        }
        printf("\n");
    }
}


void free_memory(node_t** explored, int num) {
	int i;
	for(i = 0; i<num; i++) {
		free(explored[i]);
	}
	free(explored);
}


void add_explored(node_t* pointerNew, node_t **explored, int i) {

	if (i > arrsize) {
		node_t **temp = realloc(explored, (++arrsize)*sizeof(node_t*));
		if(!temp) {
			perror("realloc Node"); 
			exit (EXIT_FAILURE); 
		}
		explored = temp;
	}
	explored[i] = pointerNew; 
}

void propagateBack(node_t* pointer, nodeScore_t* scoreArr, 
	propagation_t propagation) {

	uint32_t score = pointer->priority;

	node_t* prop = pointer->parent;
	
	move_t i;
	for (i = left; i<=down; i++) {
		if (score>=scoreArr[i].score) {
			for (; prop->depth > 1; prop = prop->parent) {
				
			}
		}
		break;
	}
	
	if (prop->move == left) {
		scoreArr[left].score = score;
	}
	if (prop->move == right) {
		scoreArr[right].score = score;
	}
	if (prop->move == up) {
		scoreArr[up].score = score;
	}
	if (prop->move == down) {
		scoreArr[down].score = score;
	}
//	free(prop);
}

move_t select_bestAction(nodeScore_t* scoreArr) {

	move_t bestMove;
	uint32_t score = (uint32_t)0;
	
	move_t i;
	for (i = left; i<=down; i++) {
		if (scoreArr[i].score >= score) {
			bestMove = i;
			score = scoreArr[i].score;
		}
	}
	
	return bestMove;
}

node_t* applyAction(node_t* pointer, move_t dirn) {
	int i,j, doubles = 0;
	
	node_t* new = initializePointer();
	assign_board(new->board, pointer->board); //Assign node elements
	new->priority = pointer->priority;
	bool success = execute_move_t(new->board, &new->priority, dirn);	
	if (success) {
		addRandom(new->board);
	} else {
		return NULL;
	}
	
	/*
	for (i = 0; i<SIZE; i++) {
		for (j=0; j<SIZE; j++) {
			if (new->board[i][j] == 2) {
				doubles += 2;
			}
			if (new->board[i][j] == 4) {
				doubles += 1;
			}
		}
	}
	*/
	updateVariables(new, pointer, dirn, doubles);
	return new;
}
